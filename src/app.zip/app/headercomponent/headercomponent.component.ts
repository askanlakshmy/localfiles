import { Component } from '@angular/core';

@Component({
  selector: 'app-headercomponent',
  templateUrl: './headercomponent.component.html',
  styleUrls: ['./headercomponent.component.css']
})
export class HeadercomponentComponent {

  imageUrl: string = 'assets/images/apollo-cancer.png';
}
